# 🎮 PUBG Booster VPN - بوستر ببجي

## تطبيق أندرويد متخصص لتعزيز لعبة ببجي موبايل

---

## المميزات الكاملة

✅ **VPN متخصص لببجي موبايل** - يوجه فقط ترافيك اللعبة  
✅ **كل مناطق ببجي** - الشرق الأوسط، آسيا، أوروبا، أمريكا، اليابان، كوريا  
✅ **قياس البينج الحي** - يعرض البينج لكل سرفر قبل الاتصال  
✅ **6 لغات** - العربية 🇸🇦، الإنجليزية 🇺🇸، الصينية 🇨🇳، اليابانية 🇯🇵، الكورية 🇰🇷، التركية 🇹🇷  
✅ **إحصائيات حية** - البينج، السرعة، مدة الاتصال  
✅ **اتصال تلقائي** - عند فتح اللعبة  
✅ **تصميم احترافي** - داكن مع ألوان PUBG الذهبية  
✅ **إشعار دائم** - مع زر قطع الاتصال السريع  

---

## متطلبات النظام

- Android Studio Hedgehog (2023.1.1) أو أحدث
- Android SDK 34
- JDK 8 أو أحدث
- Gradle 8.1+

---

## ⚠️ ما تحتاج لإعداده (مطلوب للتشغيل الحقيقي)

### 1. إعداد سرفرات WireGuard

التطبيق يستخدم بروتوكول WireGuard. تحتاج إلى:

```bash
# تثبيت WireGuard على السرفر (Ubuntu/Debian)
apt install wireguard

# إنشاء مفاتيح السرفر
wg genkey | tee server_private.key | wg pubkey > server_public.key

# إعداد WireGuard interface
cat > /etc/wireguard/wg0.conf << EOF
[Interface]
Address = 10.0.0.1/24
PrivateKey = $(cat server_private.key)
ListenPort = 51820

[Peer]
# للعميل - ضع مفتاح العميل هنا
PublicKey = CLIENT_PUBLIC_KEY
AllowedIPs = 10.0.0.2/32
EOF

# تشغيل WireGuard
wg-quick up wg0
systemctl enable wg-quick@wg0
```

### 2. تحديث معلومات السرفرات في الكود

افتح `ServerManager.kt` وعدّل كل سرفر:

```kotlin
Server(
    id = "me-uae-1",
    host = "YOUR_SERVER_IP",          // ← IP سرفرك
    port = 51820,                      // ← البورت
    wgPublicKey = "YOUR_PUBLIC_KEY",   // ← المفتاح العام للسرفر
    ...
)
```

### 3. إضافة مكتبة WireGuard (اختياري - للتشغيل الحقيقي)

في `app/build.gradle`:
```gradle
implementation 'com.wireguard.android:tunnel:1.0.20230206'
```

ثم عدّل `PubgVpnService.kt` لاستخدام WireGuard Tunnel API.

---

## البناء والتشغيل

```bash
# 1. افتح المشروع في Android Studio
# File → Open → اختر مجلد PubgBooster

# 2. انتظر تحميل Gradle dependencies

# 3. شغّل على جهازك
# Run → Run 'app'
```

---

## الصلاحيات المطلوبة (يطلبها من المستخدم)

| الصلاحية | السبب |
|----------|-------|
| `BIND_VPN_SERVICE` | إنشاء الـ VPN - يطلب موافقة المستخدم |
| `INTERNET` | الاتصال بالسرفرات |
| `FOREGROUND_SERVICE` | إشعار دائم أثناء الاتصال |
| `RECEIVE_BOOT_COMPLETED` | الاتصال التلقائي عند إعادة التشغيل |
| `POST_NOTIFICATIONS` | إشعارات Android 13+ |

---

## هيكل المشروع

```
app/src/main/
├── kotlin/com/pubgbooster/vpn/
│   ├── PubgBoosterApp.kt       # Application class
│   ├── SplashActivity.kt       # شاشة البداية
│   ├── MainActivity.kt         # الشاشة الرئيسية
│   ├── ServerSelectActivity.kt # اختيار السرفر
│   ├── SettingsActivity.kt     # الإعدادات
│   ├── StatsActivity.kt        # الإحصائيات
│   ├── service/
│   │   └── PubgVpnService.kt  # خدمة VPN الأساسية
│   ├── manager/
│   │   ├── ServerManager.kt   # إدارة السرفرات والبينج
│   │   └── PreferenceManager.kt # الإعدادات المحفوظة
│   ├── model/
│   │   └── Server.kt          # نماذج البيانات
│   ├── adapter/
│   │   └── ServerAdapter.kt   # RecyclerView adapter
│   └── util/
│       └── LocaleHelper.kt    # تبديل اللغة
└── res/
    ├── layout/                 # واجهات المستخدم
    ├── values/                 # الألوان والنصوص (إنجليزي)
    ├── values-ar/              # عربي
    ├── values-zh/              # صيني
    ├── values-ja/              # ياباني
    ├── values-ko/              # كوري
    ├── values-tr/              # تركي
    ├── drawable/               # الأيقونات والخلفيات
    └── anim/                   # الحركات
```

---

## الأسئلة الشائعة

**هل يعمل التطبيق بدون سرفرات؟**  
يمكنك تشغيله وفحص الواجهة، لكن الاتصال الحقيقي يحتاج سرفرات WireGuard.

**ما هي أفضل مناطق ببجي للاتصال؟**  
- الشرق الأوسط (🇦🇪) للاعبي دول الخليج والعرب
- آسيا (🇸🇬) للاعبي جنوب شرق آسيا
- أوروبا (🇩🇪) للاعبي أوروبا

**كيف أضيف سرفرات أكثر؟**  
أضف عنصر جديد في `ServerManager.allServers` في `ServerManager.kt`.

---

## الترخيص

هذا المشروع مفتوح المصدر للأغراض التعليمية.  
⚠️ تأكد من الامتثال لشروط خدمة Tencent/PUBG عند النشر.

---

**صنع بـ ❤️ لمجتمع ببجي العربي**
