package com.pubgbooster.vpn

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pubgbooster.vpn.databinding.ActivityStatsBinding
import com.pubgbooster.vpn.service.PubgVpnService
import kotlinx.coroutines.*

class StatsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStatsBinding
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.connection_stats)
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        setupStats()
    }

    private fun setupStats() {
        val server = PubgVpnService.connectedServer
        if (server != null) {
            binding.tvConnectedServer.text = "${server.flag} ${server.regionKey}"
            binding.tvCurrentPing.text = "${PubgVpnService.currentPing}ms"
        }

        PubgVpnService.onStatsUpdated = { ping, down, up ->
            runOnUiThread {
                binding.tvCurrentPing.text = "${ping}ms"
                binding.tvDownloadSpeed.text = String.format("%.1f Mbps", down)
                binding.tvUploadSpeed.text = String.format("%.1f Mbps", up)
                updatePingQuality(ping)
            }
        }
    }

    private fun updatePingQuality(ping: Int) {
        val (qualityText, colorRes) = when {
            ping < 50 -> Pair(getString(R.string.ping_excellent), R.color.ping_excellent)
            ping < 100 -> Pair(getString(R.string.ping_good), R.color.ping_good)
            ping < 150 -> Pair(getString(R.string.ping_average), R.color.ping_average)
            else -> Pair(getString(R.string.ping_bad), R.color.ping_bad)
        }
        binding.tvPingQuality.text = qualityText
        binding.tvPingQuality.setTextColor(getColor(colorRes))
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
