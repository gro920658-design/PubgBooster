package com.pubgbooster.vpn.adapter

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.pubgbooster.vpn.R
import com.pubgbooster.vpn.databinding.ItemServerBinding
import com.pubgbooster.vpn.model.Server

class ServerAdapter(
    private var servers: MutableList<Server>,
    private var selectedServerId: String?,
    private val onServerSelected: (Server) -> Unit
) : RecyclerView.Adapter<ServerAdapter.ServerViewHolder>() {

    inner class ServerViewHolder(val binding: ItemServerBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(server: Server) {
            val ctx = binding.root.context
            val res = ctx.resources
            val pkg = ctx.packageName

            binding.tvFlag.text = server.flag

            // Name from string resources
            val nameId = res.getIdentifier(server.nameKey, "string", pkg)
            binding.tvServerName.text = if (nameId != 0) ctx.getString(nameId) else server.nameKey

            // Region
            val regionId = res.getIdentifier(server.regionKey, "string", pkg)
            binding.tvRegion.text = if (regionId != 0) ctx.getString(regionId) else server.regionKey

            // Ping
            when {
                server.ping < 0 -> {
                    binding.tvPing.text = ctx.getString(R.string.pinging)
                    binding.tvPing.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary))
                }
                server.ping == 0 -> {
                    binding.tvPing.text = "---"
                    binding.tvPing.setTextColor(ContextCompat.getColor(ctx, R.color.ping_bad))
                }
                else -> {
                    binding.tvPing.text = "${server.ping}ms"
                    binding.tvPing.setTextColor(getPingColor(ctx, server.ping))
                }
            }

            // Recommended badge
            binding.tvRecommended.visibility = if (server.isRecommended)
                android.view.View.VISIBLE else android.view.View.GONE

            // Online indicator
            binding.ivOnlineIndicator.imageTintList = ColorStateList.valueOf(
                ContextCompat.getColor(
                    ctx,
                    if (server.isOnline) R.color.ping_excellent else R.color.ping_bad
                )
            )

            // Selected state
            val isSelected = server.id == selectedServerId
            binding.root.setBackgroundResource(
                if (isSelected) R.drawable.bg_server_selected
                else R.drawable.bg_server_normal
            )
            binding.ivCheck.visibility = if (isSelected)
                android.view.View.VISIBLE else android.view.View.GONE

            binding.root.setOnClickListener {
                val oldSelected = selectedServerId
                selectedServerId = server.id
                onServerSelected(server)
                notifyItemChanged(servers.indexOfFirst { it.id == oldSelected })
                notifyItemChanged(adapterPosition)
            }
        }

        private fun getPingColor(ctx: android.content.Context, ping: Int): Int {
            val colorRes = when {
                ping < 50 -> R.color.ping_excellent
                ping < 100 -> R.color.ping_good
                ping < 150 -> R.color.ping_average
                else -> R.color.ping_bad
            }
            return ContextCompat.getColor(ctx, colorRes)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerViewHolder {
        val binding = ItemServerBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ServerViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ServerViewHolder, position: Int) {
        holder.bind(servers[position])
    }

    override fun getItemCount() = servers.size

    fun updateData(newServers: List<Server>) {
        servers.clear()
        servers.addAll(newServers)
        notifyDataSetChanged()
    }

    fun updateServerPing(server: Server) {
        val index = servers.indexOfFirst { it.id == server.id }
        if (index >= 0) {
            servers[index] = server
            notifyItemChanged(index)
        }
    }
}
