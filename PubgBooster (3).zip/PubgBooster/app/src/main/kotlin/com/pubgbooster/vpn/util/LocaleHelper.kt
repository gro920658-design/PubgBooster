package com.pubgbooster.vpn.util

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale

object LocaleHelper {

    val supportedLanguages = listOf(
        Language("ar", "العربية", "🇸🇦"),
        Language("en", "English", "🇺🇸"),
        Language("zh", "中文", "🇨🇳"),
        Language("ja", "日本語", "🇯🇵"),
        Language("ko", "한국어", "🇰🇷"),
        Language("tr", "Türkçe", "🇹🇷")
    )

    fun setLocale(context: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.createConfigurationContext(config)
        } else {
            @Suppress("DEPRECATION")
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
            context
        }
    }

    fun isRtl(languageCode: String): Boolean {
        return languageCode == "ar"
    }

    data class Language(
        val code: String,
        val displayName: String,
        val flag: String
    )
}
