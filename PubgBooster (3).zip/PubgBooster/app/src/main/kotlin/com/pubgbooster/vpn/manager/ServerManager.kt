package com.pubgbooster.vpn.manager

import com.pubgbooster.vpn.model.PubgRegion
import com.pubgbooster.vpn.model.Server
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

object ServerManager {

    // =====================================================
    // قائمة السرفرات - كل مناطق ببجي موبايل
    // NOTE: استبدل host و wgPublicKey بمعلومات سرفراتك الحقيقية
    // =====================================================
    val allServers: List<Server> = listOf(

        // 🇦🇪 الشرق الأوسط
        Server(
            id = "me-uae-1",
            nameKey = "server_me_uae",
            regionKey = "region_middle_east",
            flag = "🇦🇪",
            host = "me-uae-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.MIDDLE_EAST,
            isRecommended = true
        ),
        Server(
            id = "me-uae-2",
            nameKey = "server_me_uae2",
            regionKey = "region_middle_east",
            flag = "🇦🇪",
            host = "me-uae-2.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.MIDDLE_EAST
        ),
        Server(
            id = "me-sa",
            nameKey = "server_me_sa",
            regionKey = "region_middle_east",
            flag = "🇸🇦",
            host = "me-sa-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.MIDDLE_EAST
        ),

        // 🌏 آسيا
        Server(
            id = "as-hk-1",
            nameKey = "server_asia_hk",
            regionKey = "region_asia",
            flag = "🇭🇰",
            host = "as-hk-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.ASIA
        ),
        Server(
            id = "as-sg-1",
            nameKey = "server_asia_sg",
            regionKey = "region_asia",
            flag = "🇸🇬",
            host = "as-sg-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.ASIA
        ),
        Server(
            id = "as-tw-1",
            nameKey = "server_asia_tw",
            regionKey = "region_asia",
            flag = "🇹🇼",
            host = "as-tw-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.ASIA
        ),

        // 🇯🇵 اليابان
        Server(
            id = "jp-1",
            nameKey = "server_japan",
            regionKey = "region_japan",
            flag = "🇯🇵",
            host = "jp-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.JAPAN
        ),

        // 🇰🇷 كوريا
        Server(
            id = "kr-1",
            nameKey = "server_korea",
            regionKey = "region_korea",
            flag = "🇰🇷",
            host = "kr-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.KOREA
        ),

        // 🌍 أوروبا
        Server(
            id = "eu-de-1",
            nameKey = "server_eu_de",
            regionKey = "region_europe",
            flag = "🇩🇪",
            host = "eu-de-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.EUROPE
        ),
        Server(
            id = "eu-nl-1",
            nameKey = "server_eu_nl",
            regionKey = "region_europe",
            flag = "🇳🇱",
            host = "eu-nl-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.EUROPE
        ),

        // 🌎 أمريكا الشمالية
        Server(
            id = "na-us-1",
            nameKey = "server_na_us",
            regionKey = "region_north_america",
            flag = "🇺🇸",
            host = "na-us-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.NORTH_AMERICA
        ),
        Server(
            id = "na-us-2",
            nameKey = "server_na_us2",
            regionKey = "region_north_america",
            flag = "🇺🇸",
            host = "na-us-2.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.NORTH_AMERICA
        ),

        // 🌎 أمريكا الجنوبية
        Server(
            id = "sa-br-1",
            nameKey = "server_sa_br",
            regionKey = "region_south_america",
            flag = "🇧🇷",
            host = "sa-br-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.SOUTH_AMERICA
        ),

        // 🇮🇳 جنوب آسيا
        Server(
            id = "sac-in-1",
            nameKey = "server_south_asia",
            regionKey = "region_south_asia",
            flag = "🇮🇳",
            host = "sac-in-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.SOUTH_ASIA
        ),

        // 🇷🇺 شرق أوروبا
        Server(
            id = "ru-1",
            nameKey = "server_east_europe",
            regionKey = "region_east_europe",
            flag = "🇷🇺",
            host = "ru-1.pubgbooster.com",
            port = 51820,
            wgPublicKey = "YOUR_WG_PUBLIC_KEY_HERE",
            pubgRegion = PubgRegion.EAST_EUROPE
        )
    )

    // PUBG Mobile package names (كل إصدارات اللعبة)
    val pubgPackages = listOf(
        "com.tencent.ig",          // PUBG Mobile Global
        "com.pubg.krmobile",        // PUBG Mobile KR
        "com.pubg.imobile",         // BGMI (India)
        "com.rekoo.pubgm",          // PUBG Mobile TW
        "com.vng.pubgmobile",       // PUBG Mobile VN
        "com.tencent.tmgp.pubgmhd", // PUBG Mobile HD
        "com.pubg.newstate"         // PUBG New State
    )

    fun getServersByRegion(): Map<String, List<Server>> {
        return allServers.groupBy { it.regionKey }
    }

    fun getServerById(id: String): Server? {
        return allServers.find { it.id == id }
    }

    fun getBestServer(): Server? {
        return allServers.filter { it.isOnline && it.ping > 0 }
            .minByOrNull { it.ping }
    }

    // قياس البينج لكل السرفرات
    suspend fun pingAllServers(onProgress: (Server) -> Unit) {
        withContext(Dispatchers.IO) {
            allServers.forEach { server ->
                server.ping = measurePing(server.host, server.port)
                server.isOnline = server.ping > 0
                onProgress(server)
            }
            // تحديد أفضل سرفر
            getBestServer()?.isRecommended = true
        }
    }

    // قياس البينج بدقة
    suspend fun measurePing(host: String, port: Int): Int {
        return withContext(Dispatchers.IO) {
            try {
                val start = System.currentTimeMillis()
                val socket = Socket()
                socket.connect(InetSocketAddress(host, port), 3000)
                socket.close()
                val ping = (System.currentTimeMillis() - start).toInt()
                ping
            } catch (e: Exception) {
                try {
                    // محاولة ICMP ping
                    val address = InetAddress.getByName(host)
                    val start = System.currentTimeMillis()
                    val reachable = address.isReachable(3000)
                    if (reachable) (System.currentTimeMillis() - start).toInt()
                    else -1
                } catch (e2: Exception) {
                    -1
                }
            }
        }
    }
}
