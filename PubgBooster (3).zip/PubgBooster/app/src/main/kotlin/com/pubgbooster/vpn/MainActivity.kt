package com.pubgbooster.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pubgbooster.vpn.databinding.ActivityMainBinding
import com.pubgbooster.vpn.manager.PreferenceManager
import com.pubgbooster.vpn.manager.ServerManager
import com.pubgbooster.vpn.model.ConnectionState
import com.pubgbooster.vpn.model.Server
import com.pubgbooster.vpn.service.PubgVpnService
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val VPN_REQUEST_CODE = 100
    private var selectedServer: Server? = null
    private var connectStartTime = 0L
    private val timerHandler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupVpnCallbacks()
        loadSelectedServer()
        setupClickListeners()
        updateUI(PubgVpnService.connectionState)
    }

    private fun setupVpnCallbacks() {
        PubgVpnService.onStateChanged = { state ->
            runOnUiThread { updateUI(state) }
        }
        PubgVpnService.onStatsUpdated = { ping, down, up ->
            runOnUiThread { updateStats(ping, down, up) }
        }
    }

    private fun loadSelectedServer() {
        val serverId = PreferenceManager.selectedServerId ?: "me-uae-1"
        selectedServer = ServerManager.getServerById(serverId) ?: ServerManager.allServers.first()
        updateServerCard()

        scope.launch {
            val ping = withContext(Dispatchers.IO) {
                ServerManager.measurePing(selectedServer!!.host, selectedServer!!.port)
            }
            if (ping > 0) {
                selectedServer!!.ping = ping
                binding.tvPingValue.text = "${ping}ms"
                binding.tvPingValue.setTextColor(getPingColor(ping))
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnBoost.setOnClickListener {
            when (PubgVpnService.connectionState) {
                ConnectionState.DISCONNECTED, ConnectionState.ERROR -> requestVpnPermission()
                ConnectionState.CONNECTED, ConnectionState.CONNECTING -> disconnectVpn()
                else -> {}
            }
        }

        binding.cardServer.setOnClickListener {
            if (PubgVpnService.connectionState == ConnectionState.DISCONNECTED) {
                startActivity(Intent(this, ServerSelectActivity::class.java))
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            }
        }

        binding.ibSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.cardStats.setOnClickListener {
            if (PubgVpnService.connectionState == ConnectionState.CONNECTED) {
                startActivity(Intent(this, StatsActivity::class.java))
            }
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST_CODE)
        } else {
            onActivityResult(VPN_REQUEST_CODE, Activity.RESULT_OK, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            connectVpn()
        }
    }

    private fun connectVpn() {
        val server = selectedServer ?: return
        val intent = Intent(this, PubgVpnService::class.java).apply {
            action = PubgVpnService.ACTION_CONNECT
            putExtra(PubgVpnService.EXTRA_SERVER_ID, server.id)
        }
        ContextCompat.startForegroundService(this, intent)
        connectStartTime = System.currentTimeMillis()
        vibrate()
    }

    private fun disconnectVpn() {
        val intent = Intent(this, PubgVpnService::class.java).apply {
            action = PubgVpnService.ACTION_DISCONNECT
        }
        startService(intent)
        stopTimer()
        vibrate()
    }

    private fun updateUI(state: ConnectionState) {
        when (state) {
            ConnectionState.DISCONNECTED -> {
                binding.btnBoostText.text = getString(R.string.boost_connect)
                binding.tvStatus.text = getString(R.string.status_disconnected)
                binding.tvStatus.setTextColor(getColor(R.color.status_disconnected))
                binding.rippleView.visibility = View.GONE
                binding.ivStatusIcon.setImageResource(R.drawable.ic_shield_off)
                binding.cardStats.alpha = 0.5f
                binding.btnBoost.clearAnimation()
                stopTimer()
            }
            ConnectionState.CONNECTING -> {
                binding.btnBoostText.text = getString(R.string.status_connecting)
                binding.tvStatus.text = getString(R.string.status_connecting)
                binding.tvStatus.setTextColor(getColor(R.color.status_connecting))
                binding.rippleView.visibility = View.VISIBLE
                binding.ivStatusIcon.setImageResource(R.drawable.ic_shield_connecting)
                val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
                binding.btnBoost.startAnimation(pulse)
            }
            ConnectionState.CONNECTED -> {
                binding.btnBoostText.text = getString(R.string.boost_disconnect)
                binding.tvStatus.text = getString(R.string.status_connected)
                binding.tvStatus.setTextColor(getColor(R.color.status_connected))
                binding.rippleView.visibility = View.VISIBLE
                binding.ivStatusIcon.setImageResource(R.drawable.ic_shield_on)
                binding.btnBoost.clearAnimation()
                binding.cardStats.alpha = 1.0f
                startTimer()
                val scaleAnim = AnimationUtils.loadAnimation(this, R.anim.scale_in)
                binding.ivStatusIcon.startAnimation(scaleAnim)
            }
            ConnectionState.ERROR -> {
                binding.tvStatus.text = getString(R.string.status_error)
                binding.tvStatus.setTextColor(getColor(R.color.status_error))
                binding.btnBoostText.text = getString(R.string.boost_connect)
                stopTimer()
            }
            else -> {}
        }
    }

    private fun updateStats(ping: Int, download: Double, upload: Double) {
        binding.tvPingValue.text = "${ping}ms"
        binding.tvPingValue.setTextColor(getPingColor(ping))
        binding.tvDownloadValue.text = String.format("%.1f MB/s", download / 8)
        binding.tvUploadValue.text = String.format("%.1f MB/s", upload / 8)
    }

    private fun updateServerCard() {
        val server = selectedServer ?: return
        binding.tvServerFlag.text = server.flag
        val nameId = resources.getIdentifier(server.nameKey, "string", packageName)
        binding.tvServerName.text = if (nameId != 0) getString(nameId) else server.nameKey
        val regionId = resources.getIdentifier(server.regionKey, "string", packageName)
        binding.tvServerRegion.text = if (regionId != 0) getString(regionId) else server.regionKey
    }

    private fun startTimer() {
        if (connectStartTime == 0L) connectStartTime = System.currentTimeMillis()
        timerRunnable = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - connectStartTime
                val hours = TimeUnit.MILLISECONDS.toHours(elapsed)
                val minutes = TimeUnit.MILLISECONDS.toMinutes(elapsed) % 60
                val seconds = TimeUnit.MILLISECONDS.toSeconds(elapsed) % 60
                binding.tvTimer.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                timerHandler.postDelayed(this, 1000)
            }
        }
        timerHandler.post(timerRunnable!!)
    }

    private fun stopTimer() {
        timerRunnable?.let { timerHandler.removeCallbacks(it) }
        binding.tvTimer.text = "00:00:00"
        connectStartTime = 0L
    }

    private fun getPingColor(ping: Int): Int {
        return when {
            ping < 50 -> getColor(R.color.ping_excellent)
            ping < 100 -> getColor(R.color.ping_good)
            ping < 150 -> getColor(R.color.ping_average)
            else -> getColor(R.color.ping_bad)
        }
    }

    private fun vibrate() {
        if (PreferenceManager.vibration) {
            val vibrator = getSystemService(android.os.Vibrator::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    android.os.VibrationEffect.createOneShot(
                        80, android.os.VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val serverId = PreferenceManager.selectedServerId
        if (serverId != null && serverId != selectedServer?.id) {
            selectedServer = ServerManager.getServerById(serverId)
            updateServerCard()
        }
        updateUI(PubgVpnService.connectionState)
    }

    override fun onDestroy() {
        scope.cancel()
        stopTimer()
        PubgVpnService.onStateChanged = null
        PubgVpnService.onStatsUpdated = null
        super.onDestroy()
    }
}
