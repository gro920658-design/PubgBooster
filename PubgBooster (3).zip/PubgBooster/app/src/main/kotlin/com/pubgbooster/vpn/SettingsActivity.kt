package com.pubgbooster.vpn

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.pubgbooster.vpn.databinding.ActivitySettingsBinding
import com.pubgbooster.vpn.manager.PreferenceManager
import com.pubgbooster.vpn.util.LocaleHelper

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupToolbar()
        loadSettings()
        setupListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings)
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }
    }

    private fun loadSettings() {
        binding.switchAutoConnect.isChecked = PreferenceManager.autoConnect
        binding.switchLaunchOnGame.isChecked = PreferenceManager.launchOnGame
        binding.switchVibration.isChecked = PreferenceManager.vibration
        binding.switchNotifications.isChecked = PreferenceManager.notifications

        val currentLang = LocaleHelper.supportedLanguages.find {
            it.code == PreferenceManager.language
        }
        binding.tvCurrentLanguage.text = "${currentLang?.flag} ${currentLang?.displayName}"
        binding.tvVersion.text = "1.0.0"
    }

    private fun setupListeners() {
        binding.switchAutoConnect.setOnCheckedChangeListener { _, checked ->
            PreferenceManager.autoConnect = checked
        }
        binding.switchLaunchOnGame.setOnCheckedChangeListener { _, checked ->
            PreferenceManager.launchOnGame = checked
        }
        binding.switchVibration.setOnCheckedChangeListener { _, checked ->
            PreferenceManager.vibration = checked
        }
        binding.switchNotifications.setOnCheckedChangeListener { _, checked ->
            PreferenceManager.notifications = checked
        }
        binding.cardLanguage.setOnClickListener {
            showLanguageDialog()
        }
    }

    private fun showLanguageDialog() {
        val languages = LocaleHelper.supportedLanguages
        val items = languages.map { "${it.flag} ${it.displayName}" }.toTypedArray()
        val currentIndex = languages.indexOfFirst { it.code == PreferenceManager.language }

        MaterialAlertDialogBuilder(this, R.style.MaterialAlertDialog_PubgBooster)
            .setTitle(getString(R.string.select_language))
            .setSingleChoiceItems(items, currentIndex) { dialog, which ->
                val selected = languages[which]
                PreferenceManager.language = selected.code
                dialog.dismiss()
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .show()
    }
}
