package com.pubgbooster.vpn.manager

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object PreferenceManager {
    private const val PREFS_NAME = "pubg_booster_prefs"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_SELECTED_SERVER = "selected_server_id"
    private const val KEY_AUTO_CONNECT = "auto_connect"
    private const val KEY_LAUNCH_ON_GAME = "launch_on_game"
    private const val KEY_VIBRATION = "vibration"
    private const val KEY_NOTIFICATIONS = "notifications"
    private const val KEY_THEME = "theme"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context, PREFS_NAME, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "ar") ?: "ar" // عربي افتراضي
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var selectedServerId: String?
        get() = prefs.getString(KEY_SELECTED_SERVER, "me-uae-1") // الشرق الأوسط افتراضي
        set(value) = prefs.edit().putString(KEY_SELECTED_SERVER, value).apply()

    var autoConnect: Boolean
        get() = prefs.getBoolean(KEY_AUTO_CONNECT, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_CONNECT, value).apply()

    var launchOnGame: Boolean
        get() = prefs.getBoolean(KEY_LAUNCH_ON_GAME, true)
        set(value) = prefs.edit().putBoolean(KEY_LAUNCH_ON_GAME, value).apply()

    var vibration: Boolean
        get() = prefs.getBoolean(KEY_VIBRATION, true)
        set(value) = prefs.edit().putBoolean(KEY_VIBRATION, value).apply()

    var notifications: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS, value).apply()
}
