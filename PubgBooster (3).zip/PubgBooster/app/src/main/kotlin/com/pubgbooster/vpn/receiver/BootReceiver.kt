package com.pubgbooster.vpn.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.pubgbooster.vpn.manager.PreferenceManager
import com.pubgbooster.vpn.service.PubgVpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            PreferenceManager.init(context)
            if (PreferenceManager.autoConnect) {
                val serverId = PreferenceManager.selectedServerId ?: return
                val vpnIntent = Intent(context, PubgVpnService::class.java).apply {
                    action = PubgVpnService.ACTION_CONNECT
                    putExtra(PubgVpnService.EXTRA_SERVER_ID, serverId)
                }
                context.startService(vpnIntent)
            }
        }
    }
}
